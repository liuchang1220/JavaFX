package java6399.group;

public class Student6399 {
    private String name;
    Student6399(String name){
        this.name=name;
    }

    @Override
    public String toString() {
        return  name ;
    }
}
