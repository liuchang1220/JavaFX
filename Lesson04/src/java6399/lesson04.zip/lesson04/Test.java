package java6399.lesson04;

import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        List<Integer> list=new ArrayList<>();
        list.add(1);
        list.add(5);
        list.add(50);
        findList6399(list);
    }
    private static void findList6399(List list){
        List<Integer> list5=new ArrayList<>();
        list5.addAll(list);
        Integer[] a=new Integer[list.size()];
        list.toArray(a);
        for (int i = 0; i <a.length ; i++) {
            if(a[i]%5==0){
                System.out.println(a[i]);
            }
        }
    }
}
